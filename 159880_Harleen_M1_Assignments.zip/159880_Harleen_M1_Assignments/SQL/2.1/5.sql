select Staff_Name, Staff_sal, 
       case  
       when Staff_sal>=50000 then 'A'
	   when Staff_sal>=25000 AND STAFF_SAL <50000 then 'B'
	   when Staff_sal>=10000 AND STAFF_SAL <25000 then 'C'
	   else 'D'
	   end case 
	   from staff_master;