alter table cust
add ( Gender varchar2(1),
      age number(3),
	  PhoneNo number(10)
	  );