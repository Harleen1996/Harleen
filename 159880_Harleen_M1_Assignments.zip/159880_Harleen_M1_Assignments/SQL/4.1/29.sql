create synonym synEmp for emp;
