create view Acc_view( CustomerCode,AccounHolderName,AccountNumber ,Type,Balance)
  as select CustomerId,Customername,Accountnumber,AccountType,ledgerBalance
	from AccountsMaster;