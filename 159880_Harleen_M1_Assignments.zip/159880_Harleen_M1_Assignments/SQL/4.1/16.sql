alter table AccountsMaster
add constraint Cust_acc FOREIGN KEY(CustomerId) REFERENCES CustomerMaster(CustomerId);