insert into department_master  values(seq_dept.NEXTVAL,'mech');
insert into department_master  values(seq_dept.NEXTVAL,'is');
insert into department_master  values(seq_dept.NEXTVAL,'it');