drop table Suppliers;

create table CustomerMaster
     (  CustomerId number(5) constraint CustId_PK PRIMARY KEY ,
		  CustomerName varchar2(30) not null,
		  Address1 varchar2(30) not null,
		  Address2 varchar2(30),
		  Gender varchar2(1),
		  Age number(3),
		  PhoneNo number(10)
	 );