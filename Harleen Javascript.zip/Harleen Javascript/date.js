var date= new Date();

document.write(date.getDay()+" " +date.getMonth()+" "+date.getFullYear()+" "+date.getHours());
document.write("<br>"+date);