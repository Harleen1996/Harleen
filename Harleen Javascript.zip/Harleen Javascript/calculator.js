var num1,num2
function addNumbers(){
num1= parseInt(document.arithmaticFrm.num1.value);
num2= parseInt(document.arithmaticFrm.num2.value);
var num3= num1+ num2;
document.arithmaticFrm.num3.value=num3;
}
function subtractNumbers(){
num1= parseInt(document.arithmaticFrm.num1.value);
num2= parseInt(document.arithmaticFrm.num2.value);
var num3= num1- num2;
document.arithmaticFrm.num3.value=num3;
}