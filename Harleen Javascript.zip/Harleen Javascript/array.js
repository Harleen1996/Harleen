
var strList=new Array("Satish","Kunal","Nilesh");
document.write(strList);
strList.sort()
document.write("<br>"+strList);
strList.pop();
document.write("<br>"+strList);
strList.push("Manu");
document.write("<br>"+strList);
