var var1="Hello world"

function work()
{
	var var1="Inside function Hello world";
	document.write("<br>Value of var1"+var1);
}

document.write("<br>Value of var1" +var1);
work();
document.write("<br>value of var1"+var1);
	