var  myWindow;
function showAlertBox(){
	window.alert("Alert message");
}
function showConfirmationBox(){
	var status=window.confirm();
}
function showInputBox(){
	var name=window.prompt("enter name");
	window.alert("Entered name "+name);
}
<!--
function openIt(){
 myWindow=open('','mywin','height=300,width=300,scrollbars=yes');
 myWindow.document.writeln("<html><head><title>fun</title></head><body>");
 myWindow.document.writeln("<table bgcolor='#ffcc66' border='1' width='600'><tr><td>");
 myWindow.document.writeln("<h1>Javascript window methods</h1><br /><br /><br />");
 myWindow.document.writeln("</tr></td></table></body></html>");
 mywindow.document.close();
 mywindow.focus();
 myWindow.alert("Hello world");
 }
 -->
 function openIt(){
myWindow = open('','mywin','height=300,width=300,scrollbars=yes');
myWindow.document.writeln("<html><head><title>fun</title></head><body>");
myWindow.document.writeln("<table bgcolor='#ffcc66' border='1' width='600'><tr><td>");
myWindow.document.writeln("<h1>JavaScript Window Methods</h1><br /><br /><br />");
myWindow.document.writeln("</tr></td></table></body></html>");
myWindow.document.close();
myWindow.focus();
myWindow.alert("Hello World");
}
 
  