var var1="hello_world"
document.write(var1.charAt(5));

var var2="from Harleen"
document.write(stringObject