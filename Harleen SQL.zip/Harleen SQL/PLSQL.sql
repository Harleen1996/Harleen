set serveroutput on ------------to display output-----------
----------------------------------------------------------------------------------------------

begin
	dbms_output.put_line('Welcome'); -------to print output----------
end;
/

-------------------------------------------------------------------------------------------
\\\\\\\\\\\\\\\\\\\\\\to fetch data from a column of a row\\\\\\\\\\\

declare 
	fname associate.firstname%type;
begin
	select firstname into fname from associate where associateId=1000;
	dbms_output.put_line('Name'||fname);
end;
/
-------------------------------------------------------------------------------------
\\\\\\\\\\\\\\\\\\\\\\to fetch data of all columns of a row\\\\\\\\\\\
declare
 	associateRecord associate%rowtype;
begin
	select * into associateRecord from associate where associateId=1000;
	dbms_output.put_line('associateId'||associateRecord.associateId);
	dbms_output.put_line('firstname'||associateRecord.firstname);
		
end;
/

---------------------------------------------------------------------------------------------
\\\\\\\\\\\\\\\\\\\\\\to fetch data from all the columns from a row, id is input by user\\\\\\\\\\\


declare
 	associateRecord associate%rowtype;
begin
	select * into associateRecord from associate where associateId=&id;
	dbms_output.put_line('associateId'||associateRecord.associateId);
	dbms_output.put_line('firstname'||associateRecord.firstname);
	
	
exception
	when 
		No_data_found
	then
		dbms_output.put_line('Not found');
end;
/
------------------------------------------------------------------------------
\\\\\\\\\\\\\\\\\\\\\\to fetch data from 2 columns only from a row\\\\\\\\\\\

declare
	type customtype IS RECORD(
		fName Associate.firstName%Type,
		lname Associate.lastName%Type);
	fullName customType;
begin
	select firstname,lastname into fullname from associate where associateId=&id;
	dbms_output.put_line('FirstName'||fullname.fname);
	dbms_output.put_line('lastName'||fullname.lname);
	
end;
/
------------------------------------------------------------------------------------------------

declare
	n1 number(10) :=100;
	n2 number(10) :=200;
begin
	if n1>n2
		then 
		dbms_output.put_line(n1||'is greater than'||n2);
	else
		dbms_output.put_line(n2||'is greater than'||n1);
	end if;
end;
/
---------------------------------------------------------------------------------------------------
declare
	n1 number(10) :=1;
begin
	while n1<10
		loop
			dbms_output.put_line(n1);
			n1 :=n1+1;
			end loop;
end;
/
-------------------------------------------------------------------------------------------------

declare
	n1 number(10) :=5;
begin
		if (n1/2=0) \\\\\\\\\\\\\\\\\\or\\\\\\\\\\\\\\\\\\ if mod(n1,2)=0\\\\\\\\\\\\\\\\\\\\\\\\\\\\
		then
		dbms_output.put_line('n1 is even');
		else
		dbms_output.put_line('n1 is odd');
		end if;
end;
/

--------------------------------------------------------------------------------------------------
\\\\\\\\\\\\\\\\\\\\\\to fetch data from multiple rows\\\\\\\\\\\

set server output on
declare
	CURSOR cName IS SELECT * from associate;
	associateRecord Associate%rowType;
begin
	if cName%isopen\\\\\\\\\\\\\\\\\\\\\\\\\\\\cursor should be open to fetch data\\\\\\\\\\\
	then
		null;\\\\\\\\\\\\\\\\\no action taken go to the loop\\\\\\\\\\\
	else
		open cName;
	end if;
	
	loop
		fetch cName into associateRecord;
		EXIT WHEN cname%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE(associateRecord.firstName||' '||associateRecord.lastName);
	end loop;
end;
/
-------------------------------------------------------------------------------------------------

set server output on
declare
	CURSOR cName IS SELECT
	* from associate where associateId=&Id;
	associateRecord Associate%rowType;
	Associate_Not_Found EXCEPTION;
begin

	if cName%isopen
	then
		null;
	else
		open cName;
	end if;
	fetch cName into associateRecord;
	if cname%NOTFOUND
		THEN
			RAISE ASSOCIATE_NOT_FOUND;
	else
		dbms_output.put_line(associateRecord.firstName);
	end if;
	EXCEPTION
		WHEN
			ASSOCIATE_NOT_FOUND
		THEN
			dbms_output.put_line('ASSOCIATE DETAILS NOT FOUND');		
end;
/
----------------------------------------------------------------------------------------------------------------
select * from user_errors where type='PROCEDURE' and name= 'INSERT_ASSOCIATE';

CREATE OR REPLACE PROCEDURE insert_associate(
	aId in associate.associateId%type,
	yInvestment in associate.yearlyInvestmentUnder80C%type,
	fname in associate.firstName%type,
	dep in associate.department%type,
	desg in associate.designation%type,
	pCard in associate.panCard%type,
	eId in associate.emailId%type,
	MGRId in associate.managerId%type,
	MGRFNAME in associate.mGRFIRSTNAME%type,
	MGRLnAME in associate.mGRLASTNAME%type
	)
is
begin
	insert into associate values(aId,yInvestment,fname,dep,desg,pcard,eId,MGRId,MGRFNAME,MGRLNAME);
	COMMIT;
end;
/

begin
	insert_associate(106,54000,'Kunal','ADM','Con','JDNK3430','kunal@gmail.com',110,'AAA','BBB');
end;
/


-----------------------------------------------------------------------------------------------------------

select * from user_errors where type='PROCEDURE' and name='SELECT_ASSOCOCIATE';

CREATE OR REPLACE PROCEDURE SELECT_ASSOCIATE(
	aId in associate.associateId%type,
	AssociateRecord out sys_refcursor
	)
is 
begin
	open associateRecord for select * from associate where associateId=aId;
end;
/

variable associatecursor refCursor;
exec select_associate(1001,:associatecursor);
print associatecursor;
---------------------------------------------------------------------------------------------------------	

CREATE OR REPLACE FUNCTION associatecountforDepartment(
	depName in associate.department%type)
	return number is
	associateCount number(10) :=0;
begin
	select count(*) into associateCount from associate where department=depname;
	return associateCount;
end;
/

begin
	dbms_output.put_line(associatecountforDepartment('A'));
end;
/
----------------------------------------------------------------------------------
create table associateLog(
	logMessage varchar2(50),
	insertDate date
)
/

create or replace trigger
		insert_associate_trigger
		after insert on associate for each row
begin
	insert into associatelog values('record inserted',sysdate);
end;
/s
------------------------------------------------------------------------------------------	

create or replace trigger
		update_associate_trigger
		after update on associate for each row
begin
	insert into associatelog values('record updated',sysdate);
end;
/

insert into Associate
     values(107,54000,'veer','ADM','Con','JDNP3430','veer@gmail.com',110,'AAA','BBB');
	 
update Associate set managerid=41 where associateId=1000;
    
select * from associateLog;
-------------------------------------------------------------------------------------------------

