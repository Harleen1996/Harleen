\\\\\\\\\\\\\\\\\\Payroll\\\\\\\\\\\\\\\\\\

create table Associate 
	(associateId number(10) not null,
	yearlyInvestmentUnder80C number(10) not null,
	firstName varchar2(15) not null,
	lastName varchar2(15) not null,
	department varchar2(10) not null,
	designation varchar2(10) not null,
	pancard varchar2(10) not null,
	emailId varchar2(15) not null
);

alter table Associate
add constraint associate_id primary key(associateId);

insert into Associate
     values(1000,10000,'Harleen','Aggarwal','A','Analyst','AHPNH12345','harry@gmail.com');
	 
insert into Associate
     values(1001,15000,'Nitika','Goyal','A','Analyst','AHPNH12905','nit@gmail.com');
	 
insert into Associate
     values(1002,20000,'Vivek','Garg','B','Sr Analyst','AHPNH12865','viv@gmail.com');
	 
	insert into Associate
     values(1003,10000,'Rishabh','Sharma','C','Manager','AHPNH12384','ris@gmail.com');

insert into Associate
     values(1004,10000,'Hitesh','Aggarwal','B','Sr Manager','AHPNH11145','hit@gmail.com');
	 
insert into Associate
     values(1005,14000,'Deepak','Mittal','D','Analyst','AHPNH00345','deep@gmail.com');
	 
insert into Associate
     values(1006,11000,'Ayush','Sinla','A','Sr Analyst','AHPNH43345','ayu@gmail.com');
	 
insert into Associate
     values(1007,17000,'Rohan','Singh','C','Consultant','AHPNH32345','roh@gmail.com');
	 
insert into Associate
     values(1008,18000,'Kajan','Shergill','B','Consultant','AHPNH57345','kaj@gmail.com');
	 
insert into Associate
     values(1009,14000,'Shraddha','Kapoor','D','Associate','AHPNH87345','shra@gmail.com');
	 
	 
	 
	 
------------------------------------------------------------------------------------------------------
create table BankDetails
	(associateId number(10) not null,
	accountNumber number(10) not null,
	bankName varchar2(10) not null,
	ifscCode varchar2(10) not null,
	constraint fk_associateId
	foreign key(associateId)
	references associate(associateId)
	);
	
alter table BankDetails
add constraint pk_account primary key(accountNumber);

insert into BankDetails
     values(1000,1354577876,'HDFC','HDFC007');
	 
insert into BankDetails
     values(1001,2354578765,'ICICI','ICICI05');
	 
insert into BankDetails
     values(1002,6754577865,'HDFC','HDFC007');
	
insert into BankDetails
     values(1003,8954577865,'ICICI','ICICI05');
	 
insert into BankDetails
     values(1004,6754277865,'ICICI','ICICI05');
	 
insert into BankDetails
     values(1005,1834577765,'HDFC','HDFC007');
	 
insert into BankDetails
     values(1006,1374577875,'ICICI','ICICI05');
	 
insert into BankDetails
     values(1008,135457875,'HDFC','HDFC007');
	 
	 
\\\\\\\\\\\\\\\\\\\\NOTE\\\\\\\\\\\\\\\To add column\\\\\\\\\\\\\\\\\
\\\\\\\\\\\\first drop the table\\\\\
drop table bankdetails;	
\\\\\\\\\\\\\\\\\\\\\\then add values of new added column\\\\\\\\\

select a.associateId, a.firstname, a.lastname, upper(b.bankname)
from associate a,bankdetails b
where a.associateId=b.associateId and b.bankname like '%HDFC%';

							OR
\\\\\INNER JOIN\\\\
						
select a.associateId, a.firstname, a.lastname, upper(b.bankname)
from associate a JOIN bankdetails b
ON a.associateId=b.associateId and b.bankname like '%HDFC%';

\\\\\\LEFT JOIN\\\\\

select a.associateId, a.firstname, a.lastname, upper(b.bankname)
from associate a LEFT JOIN bankdetails b
ON a.associateId=b.associateId and b.bankname like '%HDFC%';

\\\\\\RIGHT JOIN\\\\\

select a.associateId, a.firstname, a.lastname, upper(b.bankname)
from associate a RIGHT JOIN bankdetails b
ON a.associateId=b.associateId and b.bankname like '%HDFC%';


\\\\\\FULL JOIN\\\\\

select a.associateId, a.firstname, a.lastname, upper(b.bankname)
from associate a FULL JOIN bankdetails b
ON a.associateId=b.associateId ;

\\\\\\\\\\\\\\\\\\\ADD COLUMN AND DELETE\\\\
ALTER TABLE ASSOCIATE
ADD MANAGERID NUMBER(10);

ALTER TABLE ASSOCIATE DROP COLUMN MANAGERID;

\\\\\\\\\\\\delete one row\\\\\\\\\\\
DELETE FROM ASSOCIATE WHERE FIRSTNAME='Harleen';


\\\\\\\\\\\\\\\\\\\who reprts to whom?\\\\\\\\\\\\

ALTER TABLE ASSOCIATE
ADD MANAGERID NUMBER(10);

update associate set managerid=101 where associateid=1000;
update associate set managerid=101 where associateid=1001;
update associate set managerid=102 where associateid=1002;
update associate set managerid=102 where associateid=1003;

ALTER TABLE ASSOCIATE
ADD MgrFirstName varchar2(20);
ALTER TABLE ASSOCIATE
ADD MgrLastName varchar2(20);

update associate set mgrFirstName='Satish' where managerid=101;
update associate set mgrFirstName='Tushar' where managerid=102;
update associate set mgrLastName='Kumar' where managerid=101;
update associate set mgrLastName='Kapoor' where managerid=102;

\\\\\\\\\\\\\\\\\\self join\\\\\\\\\\\
select a.firstname||' ' ||'reports to' ||' '||m.mgrFirstName||' '||m.mgrlastname
from associate a join associate m
on a.managerid=m.managerid;


\\\\\\\\\\\\to find which mangager has max associates\\\\\\\\\\\

select managerid, count(associateid) from associate group by managerid 
	having count(associateid)=(select max(count(associateid)) from associate group by managerid);

		
\\\\\\managers who has more than 1 associate\\\\\\\\\\\\

select managerid from associate group by managerid
	having count(associateid)>1;
	
\\\\\\\\\\\\\\\associates who has no manger\\\\\\\\\\\\\\\
	
select associateid from associate
	where managerid is null;
	

--------------------------------------------------------------------------------------------

create table Salary
	(basicSalary number(10) not null,
	hra varchar2(10) not null,
	conveyenceAllowance number(10) not null,
	otherAllowance number(10) not null,
	personalAllowance number(10) not null,
	monthlyTax number(10) not null,
	epf number(10) not null,
	companyPf number(10) not null,
	gratuity number(10) not null,
	grossSalary number(10) not null,
	netSalary number(10) not null
	);
	
insert into Salary
     values(30000,2000,1500,2000,1000,1500,5000,2000,2500,40000,50000);
	 
insert into Salary
     values(30000,2000,1500,2000,1000,1500,5000,2000,2500,40000,50000);
	
insert into Salary
     values(30000,2000,1500,2000,1000,1500,5000,2000,2500,40000,50000);
	 
insert into Salary
     values(30000,2000,1500,2000,1000,1500,5000,2000,2500,40000,50000);

insert into Salary
     values(30000,2000,1500,2000,1000,1500,5000,2000,2500,40000,50000);
	 
insert into Salary
     values(30000,2000,1500,2000,1000,1500,5000,2000,2500,40000,50000);

insert into Salary
     values(30000,2000,1500,2000,1000,1500,5000,2000,2500,40000,50000);
	 
insert into Salary
     values(30000,2000,1500,2000,1000,1500,5000,2000,2500,40000,50000);

insert into Salary
     values(30000,2000,1500,2000,1000,1500,5000,2000,2500,40000,50000);
	 
insert into Salary
     values(30000,2000,1500,2000,1000,1500,5000,2000,2500,40000,50000);
	 
	 
------------------------------------------------------------------------------------------------
create table Customer
	(customerId number(10) not null,
	firstName varchar2(10) not null,
	lastName varchar2(10) not null,
	mobileNo number(10) not null,
	emailId varchar2(20) not null,
	adharno varchar2(10) not null,
	pancardno varchar2(10) not null,
	datOfBirth varchar2(10) not null
	);
	
	alter table Customer
	add constraint pk_customerId primary key(customerId);
	
insert into Customer
     values(201,'Harleen','Aggarwal',6767543489,'harry@gmail.com',5767342354,'AHPNH12345',14011996);
	 
insert into Customer
     values(202,'Nitika','Goyal',8767543489,'nit@gmail.com',6767342354,'AHPNH12905',14011996);
	 
insert into Customer
     values(203,'Vivek','Garg',7767543489,'viv@gmail.com',7767342354,'AHPNH12865',14011996);
	 
	insert into Customer
     values(204,'Rishabh','Sharma',80767543489,'ris@gmail.com',8767342354,'AHPNH12384',14021996);

insert into Customer
     values(205,'Hitesh','Aggarwal',8167543489,'hit@gmail.com',9767342354,'AHPNH11145',14031996);
	 
insert into Customer
     values(206,'Deepak','Mittal',9867543489,'deep@gmail.com',1767342354,'AHPNH00345',14041996);
	 
insert into Customer
     values(207,'Ayush','Sinla',9887543489,'ayu@gmail.com',2767342354,'AHPNH43345',14051996);
	 
insert into Customer
     values(208,'Rohan','Singh',9997543489,'roh@gmail.com',3767342354,'AHPNH32345',14061996);
	 
insert into Customer
     values(209,'Kajan','Shergill',9988543489,'kaj@gmail.com',4767342354,'AHPNH57345',14071996);
	 
insert into Customer
     values(210,'Shraddha','Kapoor',6657543489,'shra@gmail.com',2267342354,'AHPNH87345',14081996);
	 
------------------------------------------------------------------------------------------------------
create table Address
	(city varchar2(10),
	State varchar2(10),
	pinCode number(10),
	country varchar2(10)
	);

insert into address
     values('Patiala','Punjab',147001,'India');
insert into address
     values('Sangrur','Punjab',147002,'India');
insert into address
     values('Amritsar','Punjab',147003,'India');
insert into address
     values('Jalandhar','Punjab',147004,'India');
insert into address
     values('Bathinda','Punjab',147005,'India');
insert into address
     values('Ludhiana','Punjab',147006,'India');
insert into address
     values('Batala','Punjab',147007,'India');
insert into address
     values('Patiala','Punjab',147001,'India');
insert into address
     values('chandigarh','Punjab',147002,'India');
insert into address
     values('Amritsar','Punjab',147003,'India');
	 
-------------------------------------------------------------------------------------------------------
create table Account
	(accountNo number(10),
	AccountBalance number(10),
	accountType varchar(10)
	
	);

insert into Account
     values(1234567890,50000,'Savings');
insert into Account
     values(2134567890,40000,'Credit');
insert into Account
     values(4334567890,50000,'Savings');
insert into Account
     values(7834567890,40000,'Credit');
insert into Account
     values(7734567890,50000,'Savings');
insert into Account
     values(6634567890,50000,'Savings');
insert into Account
     values(9034567890,40000,'Credit');
insert into Account
     values(6534567890,50000,'Savings');
insert into Account
     values(3434567890,40000,'Credit');
insert into Account
     values(2134567890,50000,'Savings');
	 
-------------------------------------------------------------------------------------------------
create table transaction
	(transactionId varchar2(10),
	timestamp varchar2(10),
	amount number(10),
	transactionType varchar2(10),
	transactionLocation varchar2(10),
	modeOfTransaction varchar2(10),
	transactionStatus varchar2(10)
	);
alter table transaction
	add constraint pk_transactionId primary key(transactionId);
	
insert into transaction
     values('676754365X','2PM',1000,'Withdrawal','Patiala','cash','completed');
insert into transaction
     values('576754365X','3PM',2000,'deposit','Patiala','cheque','processing');
insert into transaction
     values('476754365X','4PM',1000,'Withdrawal','Patiala','cash','completed');
insert into transaction
     values('376754365X','6PM',2000,'deposit','Patiala','cheque','processing');
insert into transaction
     values('676754265X','1PM',1000,'Withdrawal','Patiala','cash','completed');
insert into transaction
     values('579754365X','3AM',2000,'deposit','Patiala','cheque','processing');
insert into transaction
     values('670754365X','4AM',1000,'Withdrawal','Patiala','cash','completed');
insert into transaction
     values('571754365X','6AM',2000,'deposit','Patiala','cheque','processing');
insert into transaction
     values('673754365X','1AM',1000,'Withdrawal','Patiala','cash','completed');
insert into transaction
     values('574754365X','2.20AM',2000,'deposit','Patiala','cheque','processing');
	 
-----------------------------------------------------------------------------------------------

create table Customer
	(customerId number(10) not null,
	firstName varchar2(10) not null,
	lastName varchar2(10) not null,
	mobileNo number(10) not null,
	emailId varchar2(20) not null,
	adharno varchar2(10) not null,
	pancardno varchar2(10) not null,
	datOfBirth varchar2(10) not null
	);
	
	alter table Customer
	add constraint pk_customerId primary key(customerId);
	
insert into Customer
     values(201,'Harleen','Aggarwal',6767543489,'harry@gmail.com',5767342354,'AHPNH12345',14011996);
	 
insert into Customer
     values(202,'Nitika','Goyal',8767543489,'nit@gmail.com',6767342354,'AHPNH12905',14011996);
	 
insert into Customer
     values(203,'Vivek','Garg',7767543489,'viv@gmail.com',7767342354,'AHPNH12865',14011996);
	 
	insert into Customer
     values(204,'Rishabh','Sharma',80767543489,'ris@gmail.com',8767342354,'AHPNH12384',14021996);

insert into Customer
     values(205,'Hitesh','Aggarwal',8167543489,'hit@gmail.com',9767342354,'AHPNH11145',14031996);
	 
insert into Customer
     values(206,'Deepak','Mittal',9867543489,'deep@gmail.com',1767342354,'AHPNH00345',14041996);
	 
insert into Customer
     values(207,'Ayush','Sinla',9887543489,'ayu@gmail.com',2767342354,'AHPNH43345',14051996);
	 
insert into Customer
     values(208,'Rohan','Singh',9997543489,'roh@gmail.com',3767342354,'AHPNH32345',14061996);
	 
insert into Customer
     values(209,'Kajan','Shergill',9988543489,'kaj@gmail.com',4767342354,'AHPNH57345',14071996);
	 
insert into Customer
     values(210,'Shraddha','Kapoor',6657543489,'shra@gmail.com',2267342354,'AHPNH87345',14081996);
	 
------------------------------------------------------------------------------------------------------
create table Address
	(customerId number(10) not null,
	city varchar2(10),
	State varchar2(10),
	pinCode number(10),
	country varchar2(10),
	constraint fk_customerId 
	foreign key(customerId)
	references customer(customerID)
	);

insert into address
     values(201,'Patiala','Punjab',147001,'India');
insert into address
     values(202,'Sangrur','Punjab',147002,'India');
insert into address
     values(203,'Amritsar','Punjab',147003,'India');
insert into address
     values(204'Jalandhar','Punjab',147004,'India');
insert into address
     values(205'Bathinda','Punjab',147005,'India');
insert into address
     values(206,'Ludhiana','Punjab',147006,'India');
insert into address
     values(207,'Batala','Punjab',147007,'India');
insert into address
     values(208,'Patiala','Punjab',147001,'India');
insert into address
     values(209,'chandigarh','Punjab',147002,'India');
insert into address
     values(210,'Amritsar','Punjab',147003,'India');
	 
-------------------------------------------------------------------------------------------------------
create table PostPaidAccount
	(customerId number(10) not null references customer(customerId),
	planId varchar2(10) not null references plan(planId),
	billId varchar2(10) not null references bill(billId),
	mobileNo number(10)
	);
	
alter table PostPaidAccount
	add constraint pk_mobile_no primary key(mobileNo);

insert into PostPaidAccount
     values(201,11,10000,9977886655);
insert into PostPaidAccount
     values(202,12,10001,9877886655);
insert into PostPaidAccount
     values(203,13,10002,9976886655);
insert into PostPaidAccount
     values(204,14,10003,9973886655);
insert into PostPaidAccount
     values(205,15,10004,9977886665);
insert into PostPaidAccount
     values(206,16,10005,9977886955);
insert into PostPaidAccount
     values(207,17,10006,9987886655);
insert into PostPaidAccount
     values(208,18,10007,9977186655);
insert into PostPaidAccount
     values(209,19,10008,9977826655);
insert into PostPaidAccount
     values(210,20,10009,9977846655);
	 
------------------------------------------------------------------------------------------
create table Plan
	(planId varchar2(10) not null,
	monthlyRental varchar2(10) not null,
	freeLocalCalls varchar2(10) not null,
	freeStdCalls varchar2(10) not null,
	freeLocalSMS varchar2(10) not null,
	freestdSMS varchar2(10) not null,
	freeInternetDataUsageUnits varchar2(10) not null,
	localCallRate varchar2(10) not null,
	stdCallRate varchar2(10) not null,
	localSMSRate varchar2(10) not null,
	stdSMSRate varchar2(10) not null,
	InternetDataUsageRate varchar2(10) not null
	);
	
alter table Plan
	add constraint pk_planId primary key(planId);
	
insert into Plan
     values(11,500,200,200,200,200,'1024MB','0.30permin','0.90permin','0.20permsg','0.30permsg','1024MB');
insert into Plan
     values(12,500,200,200,200,200,'1024MB','0.30permin','0.90permin','0.20permsg','0.30permsg','1024MB');
insert into Plan
     values(13,500,200,200,200,200,'1024MB','0.30permin','0.90permin','0.20permsg','0.30permsg','1024MB');
insert into Plan
     values(14,500,200,200,200,200,'1024MB','0.30permin','0.90permin','0.20permsg','0.30permsg','1024MB');
insert into Plan
     values(15,500,200,200,200,200,'1024MB','0.30permin','0.90permin','0.20permsg','0.30permsg','1024MB');
insert into Plan
     values(16,500,200,200,200,200,'1024MB','0.30permin','0.90permin','0.20permsg','0.30permsg','1024MB');
insert into Plan
     values(17,500,200,200,200,200,'1024MB','0.30permin','0.90permin','0.20permsg','0.30permsg','1024MB');
insert into Plan
     values(18,500,200,200,200,200,'1024MB','0.30permin','0.90permin','0.20permsg','0.30permsg','1024MB');
insert into Plan
     values(19,500,200,200,200,200,'1024MB','0.30permin','0.90permin','0.20permsg','0.30permsg','1024MB');
insert into Plan
     values(20,500,200,200,200,200,'1024MB','0.30permin','0.90permin','0.20permsg','0.30permsg','1024MB');
	 
---------------------------------------------------------------------------------------------------------------------------------

create table Bill
	(billId varchar2(10) not null,
	noOfLocalSMS varchar2(10) not null,
	noOfSTDSMS varchar2(10) not null,
	noOfLocalCalls varchar2(10) not null,
	noOfSTDCalls varchar2(10) not null,
	InternetDataUsageUnits varchar2(10) not null,
	InternetDataUsageUnitsAmount varchar2(10) not null,
	billMonth date not null,
	stateGST varchar2(10) not null,
	centralGST varchar2(10) not null,
	totalBillAmount varchar2(10) not null,
	LocalSMSAmount varchar2(10) not null,
	StdSMSAmount varchar2(10) not null,
	LocalCallAmount varchar2(10) not null
	);

	alter table Bill
	add constraint pk_bill_id primary key(billId);            
	
insert into bill
	values(10000,200,200,500,500,'1024MB',100,to_date('Jan','Month'),'2.5%','2.5%',10000,200,200,200);
insert into bill
	values(10001,200,200,500,500,'1024MB',100,to_date('Jan','Month'),'2.5%','2.5%',10000,200,200,200);
insert into bill
	values(10002,200,200,500,500,'1024MB',100,to_date('Jan','Month'),'2.5%','2.5%',10000,200,200,200);
insert into bill
	values(10003,200,200,500,500,'1024MB',100,to_date('Jan','Month'),'2.5%','2.5%',10000,200,200,200);   
insert into bill
	values(10004,200,200,500,500,'1024MB',100,to_date('Jan','Month'),'2.5%','2.5%',10000,200,200,200);
insert into bill
	values(10005,200,200,500,500,'1024MB',100,to_date('Jan','Month'),'2.5%','2.5%',10000,200,200,200);
insert into bill
	values(10006,200,200,500,500,'1024MB',100,to_date('Jan','Month'),'2.5%','2.5%',10000,200,200,200);
insert into bill
	values(10007,200,200,500,500,'1024MB',100,to_date('Jan','Month'),'2.5%','2.5%',10000,200,200,200);
insert into bill
	values(10008,200,200,500,500,'1024MB',100,to_date('Jan','Month'),'2.5%','2.5%',10000,200,200,200);
insert into bill
	values(10009,200,200,500,500,'1024MB',100,to_date('Jan','Month'),'2.5%','2.5%',10000,200,200,200);
	
