create table Emp
	(Empno number(4) not null,
	Ename varchar2(10),
	job varchar2(9),
	mgr number(4),
	Hiredate date,
	Sal number(7,2),
	Comm number(7,2),
	Deptno number(2)
	);

---------------------------------------------------------
create table Designation_Master
	(Design_code number(3) not null,
	Design_name varchar2(50)
	);

---------------------------------------------------------

create table Department_Master
	(Dept_Code number(2) not null,
	Dept_name varchar2(50)
	);

---------------------------------------------------------

create table Student_Master
	(Student_Code number(6) not null,
	Student_name varchar2(50) not null,
	Dept_Code number(2),
	Student_dob date,
	Student_Address varchar2(240)
	);

----------------------------------------------------------

create table Student_Marks
	(Student_code number(6),
	Student_Year number not null,
	Subject1 number(3),
	Subject2 number(3),
	Subject3 number(3)
	);
-----------------------------------------------------------
create table Staff_Master
	(Staff_code number(8) not null,
	Staff_Name varchar(50) not null,
	Design_code number,
	Dept_code number,
	HireDate date,
	Staff_dob date,
	Staff_address varchar2(240),
	Mgr_code number(8),
	staff_sal number(10,2)
	);
------------------------------------------------------------
create table Book_Master
	(Book_Code number(10) not null,
	Book_Name varchar2(50) not null,
	Book_pub_year number,
	Book_pub_author varchar2(50) not null
	);

--------------------------------------------------------------
create table Book_Transactions
	(Book_Code number,
	Student_Code number,
	Staff_Code number,
	Book_issue_date date not null,
	Book_expected_return_date date not null,
	Book_actual_return_date date
	);
--------------------------------------------------------------
1.1

1.

insert into Staff_Master
	values(100,'Harleen',001,11,to_date('14-01-2001','DD-MM-YYYY'),to_date('24-02-1996','DD-MM-YYYY'),'Patiala',91,50000);
insert into Staff_Master
	values(101,'Nitika',002,12,to_date('18-02-2004','DD-MM-YYYY'),to_date('13-09-1994','DD-MM-YYYY'),'Bathinda',92,50000);
insert into Staff_Master
	values(102,'Vivek',003,13,to_date('23-04-2003','DD-MM-YYYY'),to_date('08-01-1995','DD-MM-YYYY'),'Bathinda',92,13000);



update Staff_master set hiredate='14-Jan-1996' where Staff_name='Harleen';
update Staff_master set hiredate='23-April-1999' where Staff_name='Vivek';

SELECT * FROM STAFF_MASTER WHERE (HIREDATE<'01-jAN-2003') and staff_sal between 12000 and 25000 ;


2.

select * from Staff_Master where (MONTHS_BETWEEN(SYSDATE,HIREDATE))>=216;


				OR


select * from Staff_Master where trunc(MONTHS_BETWEEN(SYSDATE,HIREDATE)/12)>18;	

3.

insert into Staff_Master
	values(103,'Hitesh',004,14,to_date('12-07-1998','DD-MM-YYYY'),to_date('08-01-1995','DD-MM-YYYY'),'Patna',NULL,13000);

select * from Staff_Master where mgr_code is null;

4.

insert into Book_Master
	values(001,'Maths',2001,'Manu');
insert into Book_Master
	values(002,'English',2004,'AK');
insert into Book_Master
	values(003,'Punjabi',2005,'Gopal');
insert into Book_Master
	values(004,'Hindi',2002,'Kalra');

update Book_master set Book_name='Maths' || '&' ||'Maths' where book_code=001;

select * from Book_Master where (book_pub_year between 2001 and 2004) and Book_name like '%&%';


//////////////Note/////////////////
update Book_master set Book_name='s' || '&' ||'Maths' where book_code=001;

select * from Book_Master where (book_pub_year between 2001 and 2004) and Book_name like '_&%';
					
				OR
update Book_master set Book_name='&' ||'Maths' where book_code=001;
select * from Book_Master where (book_pub_year between 2001 and 2004) and Book_name like '&%';

				OR
update Book_master set Book_name='_' ||'Maths' where book_code=001;
select * from Book_Master where (book_pub_year between 2001 and 2004) and Book_name like '%/_%' ESCAPE '/';
select * from Book_Master where (book_pub_year between 2001 and 2004) and Book_name like '_/_%' ESCAPE '/';
	
update Book_master set Book_name='%' ||'Maths' where book_code=001;
select * from Book_Master where (book_pub_year between 2001 and 2004) and Book_name like '%/%%' ESCAPE '/';

update Book_master set Book_name='\Maths' where book_code=001;
select * from Book_Master where (book_pub_year between 2001 and 2004) and Book_name like '\%';

update Book_master set Book_name='_Maths' where book_code=001;
update Book_master set Book_name='%Maths' where book_code=001;
update Book_master set Book_name='&Maths' where book_code=001;   //NOT VALID 

4.

update Book_master set Book_name='_' ||'Maths' where book_code=001;
select * from Book_Master where (book_pub_year between 2001 and 2004) and Book_name like '%/_%' ESCAPE '/';
select * from Book_Master where (book_pub_year between 2001 and 2004) and Book_name like '_/_%' ESCAPE '/';

------------------------------------------------------------------------------------------------------------------

2.1

1.

select staff_name,
LPAD(staff_sal,15,'$')salary
from staff_master;

2.


insert into student_master
	values(100,'Harleen',01,'01-jan-1996','Patiala');
insert into student_master
	values(101,'Nitika',02,'15-sep-2018','Bathinda');
insert into student_master
	values(102,'Vivek',03,'01-april-1996','Ludhiana');



SELECT STUDENT_NAME,
TO_CHAR(STUDENT_DOB,'MONTH, DD YYYY') AS STUDENT_DOB FROM STUDENT_MASTER WHERE TO_CHAR(STUDENT_DOB,'DAY') LIKE  ('%SATURDAY%') OR TO_CHAR(STUDENT_DOB,'DAY') LIKE  ('%SUNDAY%') ;


3.

select staff_name, ROUND(MONTHS_BETWEEN(SYSDATE,HIREDATE)) as MONTHs_WORKED from staff_master order by MONTHS_WORKED;


4.

insert into Staff_Master
	values(103,'Hitesh',004,14,to_date('05-12-2003','DD-MM-YYYY'),to_date('09-01-1995','DD-MM-YYYY'),'Patna',93,13000);
insert into Staff_Master
	values(104,'Rishabh',005,15,to_date('23-12-2003','DD-MM-YYYY'),to_date('08-08-1996','DD-MM-YYYY'),'Khanna',94,13000);
SELECT * FROM STAFF_MASTER where to_char(hiredate,'DD') between 1 and 15 and to_char(hiredate,'MONTH') like '%DECEMBER%';

5.

select staff_name,staff_sal,
	case 
	when staff_sal >=50000 then 'A'
	when staff_sal >=25000 and staff_sal <50000 then 'B'
	when staff_sal >=10000 and staff_sal <25000 then 'C'
	else 'D'
	END as "GRADE"
	from staff_master;
	
6.

select staff_name,to_char(hiredate,'dd month yyyy') as hire_date, to_char(hiredate,'DAY') as DAY from staff_master order by to_char(hiredate-3,'D')  ;
	
7.

SELECT INSTR('Mississippi','i',2,3) FROM DUAL;

8.

select TO_CHAR((next_day(last_day(sysdate)-c7,'FRIDAY')), 'Ddspth') || ' of ' || TO_CHAR((next_day(last_day(sysdate)-7,'FRIDAY')), 'Month, YYYY') FROM DUAL; 

9.

update student_master set dept_code=20 where student_code=100;
update student_master set dept_code=30 where student_code=101;

SELECT STUDENT_CODE,STUDENT_NAME,DECODE(DEPT_CODE,20,'ELECTRICALS',30,'ELECTRONICS','OTHERS') as DEPARTMENT_NAME FROM STUDENT_MASTER;
-----------------------------------------------------------------------------------------------------------------------------------------------

2.2

1.

select round(max(staff_sal)) as "maximum", round(min(staff_sal)) as "minimum", round(sum(staff_sal)) as "total", round(avg(staff_sal)) as "average" from staff_master group by dept_code;
	
2.

select dept_code, count(mgr_code) as "total no. of managers" from staff_manager group by dept_code;

3.
select dept_code, sum(staff_sal) from staff_master where mgr_code is null group by dept_code having sum(staff_sal)>20000;	

---------------------------------------------------------------------------------------------------------------------------------
3.1Joins and subqueries

1.
select a.staff_name,a.dep_code,dept_name,a.staff_sal
	from staff_master a
	join department_master b on a.dep_code=b.dep_code
	where a.staff_sal>2000;
----------------------------------------------------------------------

2.

select a.staff_code as "Staff#",a.staff_name as staff,b.dept_name,a.mgr_code as Mgr#,a.mgr_name as Manager
	from staff_master a
	join department_master b on a.dept_code=b.dept_code;
	
----------------------------------------------------------------------------------------------------------------------
3.

select a.student_code,a.student_name,b.book_code,b.book_name
	from student_master a
	join book_transaction c on a.student_code=c.student_code
	join book_master b on c.book_code=b.book_code
	where to_char(c.book_expected_return_date,'DD MM YYYY') like to_char(sysdate,'DD MM YYYY');
--------------------------------------------------------------------------------------------------------------------
4.select a.staff_code,a.staff_name,b.dept_name,c.design_name,d.book_code,d.book_name,e.book_issue_date
	from staff_master a
		join department_master b on a.dept_code=b.dept_code
		join designation_master c on a.design_code=c.design_code
		join book_transactions e on a.staff_code=e.staff_code
		join book_master d  on e.book_code=d.book_code
			where months_between(to_char(e.book_issue_date,'mm'),to_char(sysdate,'mm'))<1;
-----------------------------------------------------------------------------------------------------------------------
5.
select a.staff_code,a.staff_name,c.design_name,d.dept_name,d.book_code,d.book_name,e.book_pub_author
	from staff_master a
		join department_master b on a.dept_code=b.dept_code
		join designation_master c on a.design_code=c.design_code
		join book_transactions e on a.staff_code=e.staff_code
		join book_master d  on e.book_code=d.book_code
-----------------------------------------------------------------------------------------------------------------------
6.

select staff_code,staff_name,staff_sal
	from staff_master where staff_sal<(select avg(staff_sal)from staff_master);
------------------------------------------------------------------------------------------------------------------------
7.
select book_pub_author as "author name",book_name from book_master;
-----------------------------------------------------------------------------------------------------------------------
8.
select b.staff_code,a.staff_name,c.dept_name
	from staff_master a
		join book_transactions b on a.staff_code=b.staff_code
		join department_master c on c.dept_code=a.dept_code
		group by a.staff_name having count(b.staff_count)>1;
-------------------------------------------------------------------------------------------------------------------------
9.

select a.student_code,a.student_name,b.dept_name
	from student_master a
	join department_master b on a.dept_code=b.dept_code
	group by b.dept_name;
------------------------------------------------------------------------------------------------------------------------
10.
select a.staff_code,a.staff_name,b.dept_name,c.design_name
	from staff_master a
	join department_master b on a.dept_code=b.dept_code
	join designation_master c on a.design_code=c.design_code
	where months_between(to_char(a.hiredate,'MM'), to_char(sysdate,'MM'))<3;
----------------------------------------------------------------------------------------------------------------------
11.
select mgr_name,count(staff_code) from staff_master;
---------------------------------------------------------------------------------------------------------------------
12.

select * from book_master b
	join book_transactions bt on b.book_code=bt.book_code
		where bt.book_actual_return_date is null
			and ceil(book_expected_return_date - next_day(sysdate-7,'MONDAY'))=0;
			
----------------------------------------------------------------------------------------------------------------------
13.
SELECT D.DEPT_CODE,D.DEPT_NAME, nvl2(count(s.student_code),count(s.student_code),0)+ NVL2(count(st.staff_code),count(st.staff_code)
	from department_master d
		left join student_master a on d.dept_code=s.dept_code
		left join staff_master a on d.dept_code=st.dept_code
	gropy by d.dept_code,d.dept_name;
	
----------------------------------------------------------------------------------------------------------------------	

4.1

1.
create table Cust
	(CustomerId number(5),
	Cust_name varchar2(20),
	Address1 varchar2(3),
	Address2 varchar2(30)
	);
	
2.

alter table cust rename column cust_name to customername;
alter table cust modify customername varchar(20) not null;

3.

alter table cust add Gender varchar2(1);
alter table cust add Age Number(3);
alter table cust add PhoneNo Number(10);
rename cust to cust_table;

4.

insert into cust_table values(&Customerid,'&customerName','&Address1','&Address2','&Gender',&Age,&phoneNo);
    1000, Allen, #115 Chicago, #115 Chicago, M, 25, 7878776
	1001, George, #116 France, #116 France, M, 25, 434524
	1002, Becker, #114 New York, #114 New York, M, 45, 431525

	               OR
				   
alter table cust_table modify address1 varchar(30);	
	insert into cust_table
		values(1000, 'Allen', '#115 Chicago', '#115 Chicago', 'M', 25, 7878776);
	insert into cust_table
		values(1001, 'George', '#116 France', '#116 France', 'M', 25, 434524);
	insert into cust_table
		values(1002, 'Becker', '#114 New York', '#114 New York', 'M', 45, 431525);
----------------------------------------------------------------------------------------------------------------
5.
alter table cust_table
add constraint CustId_Prim primary key(customerId);
-----------------------------------------------------------------------------------------------------------
6.
insert into Cust_table values(1002,'John','#114 Chicago','#114 Chicago','M','45','439525');
-------------------------------------------------------------------------------------------------------------
7.
alter table cust_table disable constraint CustId_Prim;
insert into cust_table values(1002,'Becker','#114 New York','#114 New York',,'M','45','431525');
insert into cust_table values(1002,'Becker','#114 New York','#114 New York',,'M','45','431525');
--------------------------------------------------------------------------------------------------------------

8.
alter table cust_table enable constraint CustId_Prim;
----------------------------------------------------------------------------------------------------------
9.
alter table cust_table drop constaraint CustId_Prim;
insert into cust_table values(1002,'Becker','#114 New York','#114 New York',,'M','45','431525',15000.50);
insert into cust_table values(1002,'Becker','#114 New York','#114 New York',,'M','45','431525',20000.50);
-----------------------------------------------------------------------------------------------------------------
10.
truncate table cust_table;
-----------------------------------------------------------------------------------------------------------------
11.
alter table cust_table add(E_mail vatchar2(50));
-------------------------------------------------------------------------------------------------------------------
12.
alter table cust_table drop column E_mail;
--------------------------------------------------------------------------------------------------------------------
13.
create table Suppliers
		(SuppID number(5),
		SName varchar(20),
		Addr1 varchar(30),
		Addr2 varchar(30),
		Contactno number(10)
		);
------------------------------------------------------------------------------------------------------------------------
14.
drop table Suppliers;

create table CustomerMaster
	(CustomerId nnumber(5) constarint CustId_PK primary key,
	CustomerName varchar2(30) not null,
	Address1 varchar2(30) not null,
	Address2 varchar2(30),
	Gender varchar2(1),
	Age number(3),
	PhoneNo number(10)
	);
----------------------------------------------------------------------------------------------------------------------------
15.
create table AccountMaster
	(CustomerId number(5),
	AccountNumber number(10,2) constraint Acc_PK primary,
	AccountType char(30),
	LedgerBalance number(10,2) not null
	);
-----------------------------------------------------------------------------------------------------------------------------
16.
alter table AccountMaster
add constraint Cust_acc foreign key(CustomerId) references CustomerMaster(CustomerId);
------------------------------------------------------------------------------------------------------------------------------
17.
insert into CustomerMaster values(1000,'Allen','#115 Chicago','#115 Chicago',,'M',25,7878776);
insert into CustomerMaster values(1001,'George','#116 France','#116 France',,'M',25,4343524);
insert into CustomerMaster values(1002,'Becker','#114 New York','#114 New York',,'M',25,431525);
-------------------------------------------------------------------------------------------------------------------------------
18.
alter table AccountsMaster
modify AccountTyoe char(30) check(accountType='NRI' or accountType='IND');
-----------------------------------------------------------------------------------------------------------------------------
19.
alter table AccountMaster
modify LedgerBalance number(10,2) constraint balance_Check check(ledgerBalance>5000);
----------------------------------------------------------------------------------------------------------------------------
20.
alter table AccountsMaster drop constraint Cust_acc;

alter table AccountsMaster
add constraint Cust_acc foreign key(CustomerId) references CustomerMaster(CustomerId) on delete cascade;
----------------------------------------------------------------------------------------------------------------------------------
21.
create table AccountDetails as select * from AccountMaster;
------------------------------------------------------------------------------------------------------------------------------------
22.
create view Acc_view(CustomerCode,AccountHolderName,AccountNumber,Type,Balance)
	as select CustomerId,CustomerName,AccountNumber,AccountType,ledgerBalance
	from AccountsMaster;
-----------------------------------------------------------------------------------------------------------------------------------
23.
create view vAccs_Dtls as select AccountType,ledgerBalance from accountsMaster where accountType='IND' and ledgerbalance>+10000;
-------------------------------------------------------------------------------------------------------------------------------------
24.
create view accsvw10 as select * from accountmaster with read only constraint reacc;
-------------------------------------------------------------------------------------------------------------------------------------
25.
create sequence SEQ_DEPT minvalue 40 start with 40
	increment by 10 maxvalue 200 cache 40;
	update department_master set dept_code=seq_dept.nextval;
--------------------------------------------------------------------------------------------------------------------------------------
26.
insert into department_master values(seq_dept.nextval,'mech');
insert into department_master values(seq_dept.nextval,'is');
insert into department_master values(seq_dept.nextval,'it');
---------------------------------------------------------------------------------------------------------------------------------------
27.
drop sequence SEQ_DEPT;
-----------------------------------------------------------------------------------------------------------------------------------------
28.
select * from all_indexes where index_name like '%NO_NAME%';
---------------------------------------------------------------------------------------------------------------------------------------
29.
create synonym synEmp for emp;
--------------------------------------------------------------------------------------------------------------------------------------
30.
select * from synEmp;
----------------------------------------------------------------------------------------------------------------------------------------
31.
create index idx_emp_hiredate on emp(hiredate);
---------------------------------------------------------------------------------------------------------------------------------------------------
32.
create sequence SEQ_Emp minvalue 1000 start with 1001
	increment by 1 maxvalue 2000 cache 1000;
	
	update emp set empno=seq_emp.nextval;
-----------------------------------------------------------------------------------------------------------------------
5.1

1.
create table employee as select * from emp where 1=3;
desc employee;
select * from employee;
-----------------------------------------------------------------------------------------------------------------------------------------
2.
insert into employee(empno,ename,sal,deptno) values(7369,'SMITH',800,20);
insert into employee(empno,ename,sal,deptno) values(7499,'ALLEN',1600,30);
insert into employee(empno,ename,sal,deptno) values(7521,'WARD',1250,30);
insert into employee(empno,ename,sal,deptno) values(7566,'JONES',2975,20);
insert into employee(empno,ename,sal,deptno) values(7654,'MARTIN',1250,30);
insert into employee(empno,ename,sal,deptno) values(7698,'BLAKE',2850,30);
insert into employee(empno,ename,sal,deptno) values(7782,'CLARK',2450,10);
insert into employee(empno,ename,sal,deptno) values(7788,'SCOTT',3000,20);
insert into employee(empno,ename,sal,deptno) values(7839,'KING',5000,10);
insert into employee(empno,ename,sal,deptno) values(7844,'TURNER',1500,30);
insert into employee(empno,ename,sal,deptno) values(7876,'ADAMS',1100,20);
insert into employee(empno,ename,sal,deptno) values(7900,'JAMES',950,30);
insert into employee(empno,ename,sal,deptno) values(7902,'FORD',3000,20);
insert into employee(empno,ename,sal,deptno) values(7934,'MILLER',1300,10);
---------------------------------------------------------------------------------------
3.
update employee set job=(select job from employee where empno=7788), deptno=(select deptno from employee where empno=7788) where empno=7698;
-----------------------------------------------------------------------------------------------------------------------------------------------
4.
delete from employee where departmentname like '%sales%';
-----------------------------------------------------------------------------------------------------------------------------------------------
5.
update employee set deptno=(select deptno from employee where emplno=7698) where empno=7788;
-----------------------------------------------------------------------------------------------------------------------------------------------
6.
insert into employee values(&empno,'&ename','&job',&mgr,'&hiredate',&sal,&comm,&deptno;
-------------------------------------------------------------------------------------------------------------------------------------------------
6.1

1.
insert into customerMaster values(&customerId,'&customername','&address1','&address2','&gender',&age,&phoneno);
------------------------------------------------------------------------------------------------------------------------------------------------
2.
savepoint SP1;
----------------------------------------------------------------------------------------------------------------------------------------------------
3.
insert into customerMaster values(6003,'john','#114 chicago','#114 chicago','m',45,439525);
---------------------------------------------------------------------------------------------------------------------------------------------
4.
rollback to SP1;
---------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------------

\\\\\\\\\\\\\\\\\\to find second max sal\\\\\\\\\\\\\\\\\\

	
select staff_name,staff_sal from staff_master where staff_sal= (select max(staff_sal) from staff_master where staff_sal<(select max(staff_sal) from staff_master));

					OR
select staff_name,staff_sal from staff_master where	staff_sal= (select max(staff_sal) from staff_master where staff_sal not in (select max(staff_sal) from staff_master));		

