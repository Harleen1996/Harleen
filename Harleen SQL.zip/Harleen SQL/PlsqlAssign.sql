1.

1.1

DECLARE
V_Sample1 NUMBER(2);
V_Sample2 CONSTANT NUMBER(2) ;
V_Sample3 NUMBER(2) NOT NULL ;
V_Sample4 NUMBER(2) := 50;
V_Sample5 NUMBER(2) DEFAULT 25;
BEGIN
	DBMS_OUTPUT.PUT_LINE('HELLO');
END;
/

PROBLEMS:
1.  declaration of a constant 'V_SAMPLE2' must contain an initialization assignment
2.	a variable declared NOT NULL must have an initialization assignment

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
DECLARE 
var_num1 NUMBER := 5;
BEGIN
DBMS_OUTPUT.PUT_LINE('Value for var_num1:' ||var_num1);
DECLARE 
var_num1 NUMBER := 10;
BEGIN
DBMS_OUTPUT.PUT_LINE('Value for var_num1:' ||var_num1);
END;
END;
/
--------------------------------------------------------------------------------------------------------------------------------------
1.3
create table Employee
	(employeeNo number(10) not null,
	salary number(10) not null,
	employeeName varchar2(15) not null,
	departmentName varchar2(10) not null,
	departmentCode varchar2(10) not null,
	designation varchar2(10) not null,
	pancard varchar2(10) not null,
	emailId varchar2(15) not null
);

alter table Employee
add constraint employee_No primary key(employeeNo);

insert into Employee
     values(1000,10000,'Harleen','A',1,'Analyst','AHPNH12345','harry@gmail.com');
	 
insert into Employee
     values(1001,15000,'Nitika','A','Analyst',1,'AHPNH12905','nit@gmail.com');
	 
insert into Employee
     values(1002,20000,'Vivek','B','Sr Analyst',2,'AHPNH12865','viv@gmail.com');
	 
	insert into Employee
     values(1003,10000,'Rishabh','C','Manager',3,'AHPNH12384','ris@gmail.com');

insert into Employee
     values(1004,10000,'Hitesh','B',2,'Sr Manager','AHPNH11145','hit@gmail.com');
	 
insert into Employee
     values(1005,14000,'Deepak','D',4,'Analyst','AHPNH00345','deep@gmail.com');
	 
insert into Employee
     values(1006,11000,'Ayush','A',1,'Sr Analyst','AHPNH43345','ayu@gmail.com');
	 
insert into Employee
     values(1007,17000,'Rohan','C',3,'Consultant','AHPNH32345','roh@gmail.com');
	 
insert into Employee
     values(1008,18000,'Kajan','B',2,'Consultant','AHPNH57345','kaj@gmail.com');
	 
insert into Employee
     values(7369,14000,'Shraddha','D',4,'Associate','AHPNH87345','shra@gmail.com');

-----------------------------------------------------------------------------------------------------------
1.3

set serveroutput on

declare
 	employeeRecord employee%rowtype;
begin
	select * into employeeRecord from employee where employeeNo=7369;
	dbms_output.put_line('employeeNo'||employeeRecord.employeeNo);
	dbms_output.put_line('salary'||employeeRecord.salary);
	dbms_output.put_line('employeename'||employeeRecord.employeename);
	dbms_output.put_line('departmentName'||employeeRecord.departmentName);
	dbms_output.put_line('departmentCode'||employeeRecord.departmentCode);
	dbms_output.put_line('designation'||employeeRecord.designation);
	dbms_output.put_line('pancard'||employeeRecord.pancard);
	dbms_output.put_line('emailId'||employeeRecord.emailId);
		
end;
/
---------------------------------------------------------------------------------------------------------
1.4

declare
 	employeeRecord employee%rowtype;
begin
	select * into employeeRecord from employee where employeename='&employeename';
	dbms_output.put_line('employeeNo'||employeeRecord.employeeNo);
	dbms_output.put_line('salary'||employeeRecord.salary);
	dbms_output.put_line('employeename'||employeeRecord.employeename);
	dbms_output.put_line('departmentName'||employeeRecord.departmentName);
	dbms_output.put_line('departmentCode'||employeeRecord.departmentCode);
	dbms_output.put_line('designation'||employeeRecord.designation);
	dbms_output.put_line('pancard'||employeeRecord.pancard);
	dbms_output.put_line('emailId'||employeeRecord.emailId);
		
end;
/
-------------------------------------------------------------------------------------------------------------
1.5


