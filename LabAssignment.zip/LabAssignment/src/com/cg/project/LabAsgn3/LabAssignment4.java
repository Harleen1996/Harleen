package com.cg.project.LabAsgn3;

import java.time.LocalDate;
import java.time.Period;

public class LabAssignment4 {

		public static void main(String[] args) {
		LocalDate dateFrom=LocalDate.of(2015,04,02);
		LocalDate dateTo=LocalDate.of(2017,03,07);
		Period difference=Period.between(dateFrom,dateTo);
		System.out.println("Difference of days: " + difference.getDays());
	    System.out.println("Difference of months: " + difference.getMonths());
	    System.out.println("Difference of years: " + difference.getYears());

		}

	}


