package com.cg.project.LabAsgn3;

import java.time.LocalDate;
import java.time.Period;

public class LabAssignment3 {
		public static void main(String[] args) {
			LocalDate date=LocalDate.of(2017,01,02);
			LocalDate now=LocalDate.now();
			Period difference=Period.between(date,now);
			System.out.printf("\nDifference is %d years, %d months and %d days old\n\n", difference.getYears(), difference.getMonths(), difference.getDays());
		}

	}


