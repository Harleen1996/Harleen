package com.cg.project.LabAsgn2;

public enum Gender {
	Male('M'),
	Female('F');
	
	private char gender;

	private Gender(char gender) {
		this.gender = gender;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}
	
}
