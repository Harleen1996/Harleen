package com.cg.project.LabAsgn2;

public class PersonMain {

	public static void main(String[] args) {
		Person person=new Person("Nitika", "Garg", Gender.Female,"9779422068");
		displayPersonDetails(person);
	}
	public static void  displayPersonDetails(Person person){
		System.out.println("Person Details:");
		System.out.println("----------------------");
		System.out.println("First Name: "+person.getFirstName());
		System.out.println("Last Name: "+person.getLastName());
		System.out.println("Gender: "+person.getGender().getGender());
		System.out.println("Mobile Number: "+person.getNumber());
	}
}
