package com.cg.project.LabAsgn4;

public class MainClass {

		public static void main(String[] args) {
			SavingsAccount account=new SavingsAccount(2000, new Person("Smith"));
			SavingsAccount account1=new SavingsAccount(3000, new Person("Kathy"));
			account.deposit(2000);
			account1.withdraw(2700);
			System.out.println("Updated balance in Smith's account: "+account.getBalance());
			System.out.println("Updated balance in Kathy's account: "+account1.getBalance());
			System.out.println(account.toString());
			System.out.println(account1.toString());
			

	}
	

}
