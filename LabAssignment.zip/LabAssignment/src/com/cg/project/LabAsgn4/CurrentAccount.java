package com.cg.project.LabAsgn4;

	public class CurrentAccount extends Account {
		private int overdraftLimit;
		public CurrentAccount( double balance, Person accHolder) {
			super(balance, accHolder);
			
		}
		@Override
		public void withdraw(double amount) {
			super.withdraw(amount);
			
		}
}
