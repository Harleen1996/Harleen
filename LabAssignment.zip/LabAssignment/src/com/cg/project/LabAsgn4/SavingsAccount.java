package com.cg.project.LabAsgn4;

	public class SavingsAccount extends Account {
		private final int minimumBalance=500;
		public SavingsAccount( double balance, Person accHolder) {
			super( balance, accHolder);
		}
		@Override
		public void withdraw(double amount) {
			    if((getBalance()-amount)<minimumBalance){
			        System.err.println("Minimum balance should be maintained");
			        return;
			    }
			    setBalance(getBalance()-amount);
		}

}
