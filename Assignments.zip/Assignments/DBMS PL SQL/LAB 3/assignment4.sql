create or replace procedure UPDATE_STAFF(
	stcode in staff_master.staff_code%TYPE)
is
	sal number(10) := 0;
	tcost number(10) := 0;
	hd date;
	yrs number(10) := 0;
begin
	select staff_sal, hiredate into sal, hd
	from staff_master
	where staff_code = stcode;
	yrs := months_between(sysdate, hd) / 12;
	IF (yrs < 2) THEN
		null;
	ELSIF (yrs>=2 and yrs<5) THEN
		tcost := sal + 0.2 * sal;
		INSERT INTO STAFF_MASTER_BACK
		SELECT * FROM STAFF_MASTER;
		UPDATE STAFF_MASTER
		SET STAFF_SAL = tcost
		WHERE STAFF_CODE = stcode;
	ELSE
		tcost := sal + 0.25 * sal;
		INSERT INTO STAFF_MASTER_BACK
		SELECT * FROM STAFF_MASTER;
		UPDATE STAFF_MASTER
		SET STAFF_SAL = tcost
		WHERE STAFF_CODE = stcode;
	END IF;
end ;
/

exec UPDATE_STAFF(101);
/