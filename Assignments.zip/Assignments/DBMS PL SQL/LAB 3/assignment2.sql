create or replace procedure queryStaff(
	staff OUT sys_refCursor)
is
begin
	open staff for select staff_code, staff_name, dept_code, manager_name from staff_master;
end ;
/

variable manager refCursor;
exec queryStaff(:manager);
print manager;
/
