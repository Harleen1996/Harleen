select book_pub_author as "author name",book_name from book_master ;
