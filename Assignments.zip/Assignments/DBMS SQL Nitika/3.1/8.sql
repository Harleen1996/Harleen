select b.staff_code,a.staff_name,c.dept_name 
	from staff_master a
		join book_transactions b on a.staff_code=b.staff_code
		join department_master c on c.dept_code=a.dept_code
		GROUP BY a.STAFF_NAME HAVING COUNT(b.STAFF_count)>1;