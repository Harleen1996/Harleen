select a.staff_name,a.dept_code,b.dept_name,a.staff_Sal 
	from staff_master a 
	join department_master b on a.dept_code=b.dept_code 
	where a.staff_sal>20000;