insert into customerMaster values(6003,'john','#114 chicago','#114 chicago','m',45,439525);
