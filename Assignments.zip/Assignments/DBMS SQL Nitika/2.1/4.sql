select * from staff_master where to_char(hiredate,'DD') between 1 and 15 and to_char(hiredate,'MONTH') like '%DECEMBER%';
