alter table cust_table
add constraint CustId_Prim PRIMARY KEY(CustomerId);