alter table cust_table add ( E_mail varchar2(50));
