select * from synEmp;
