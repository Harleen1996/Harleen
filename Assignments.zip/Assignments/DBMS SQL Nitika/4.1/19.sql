alter table AccountsMaster
modify LedgerBalance number(10,2) constraint Balance_Check check(ledgerBalance>5000);