create index idx_emp_hiredate on emp(hiredate);
