alter table cust_table drop column E_mail;
