insert into CustomerMaster values(1000, 'Allen', '#115 Chicago', '#115 Chicago', 'M', 25, 7878776);
insert into CustomerMaster values(1001, 'George', '#116 France', '#116 France', 'M', 25, 434524);
insert into CustomerMaster values(1002, 'Becker', '#114 New York', '#114 New York', 'M', 45, 431525);