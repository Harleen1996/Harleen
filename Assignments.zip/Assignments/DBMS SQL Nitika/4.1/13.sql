create table Suppliers
     (  SuppID number(5),
		  SName varchar2(20),
		  Addr1 varchar2(30),
		  Addr2 varchar2(30),
		  Contactno number(10)
	 );