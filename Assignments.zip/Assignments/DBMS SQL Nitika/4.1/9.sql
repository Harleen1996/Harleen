alter table cust_table drop constraint CustId_Prim;
insert into cust_table values(1002, 'Becker', '#114 New York', '#114 New york' , 'M', '45', '431525',15000.50);
insert into cust_table values(1003, 'Nanapatekar', '#115 India', '#114 India' , 'M', '45', '431525',20000.50);