CREATE TABLE Emp
        ( Empno number(4) not null,
	  Ename varchar2(10),
	  job varchar2(9),
	  mgr number(4),
	  Hiredate date,
	  Sal number(7,2),
	  Comm number(7,2),
	  Deptno number(2)
	 );

insert into Emp values(1,'nitika','full time','1','01-oct-2002',15000,1,1);
insert into Emp values(2,'aman','full time',null,'11-aug-2003',25000,2,2);
insert into Emp values(3,'harleen','part time','1','21-oct-2001',35000,1,1);
insert into Emp values(4,'rahul','part time',null,'08-april-2018',45000,3,2);
insert into Emp values(5,'vinay','full time','1','10-nov-2015',65000,3,1);
insert into Emp values(6,'nitin','full time','2','27-nov-2000',18000,2,2);
------------------------------------

CREATE TABLE Designation_Master
	( Design_code number(3) not null,
	  Design_name varchar2(50)
	);

insert into Designation_Master values(101, 'senior analyst');
insert into Designation_Master values(102, 'analyst');
insert into Designation_Master values(101, 'senior analyst');
insert into Designation_Master values(102, 'analyst');
insert into Designation_Master values(101, 'senior analyst');
insert into Designation_Master values(102, 'analyst');
------------------------------------

CREATE TABLE Department_Master
	( Dept_Code number(2) not null,
	  Dept_name varchar2(50)
	);

	insert into Department_Master values(1,'cse');
	insert into Department_Master values(2,'ece');
	insert into Department_Master values(3,'ee');
	insert into Department_Master values(4,'civil');

---------------------------------------

CREATE TABLE Student_Master
	( Student_Code number(6) not null,
	  Student_name varchar2(50) not null,
	  Dept_Code number(2),
	  Student_dob date,
	  Student_Address varchar2(240)
	);
	

insert into Student_Master values(111,'nitika',10,'01-jan-1994','abc');
insert into Student_Master values(112,'aman',10,'11-jan-1994','xyz');
insert into Student_Master values(113,'sahil',12,'31-dec-1993','abc');
insert into Student_Master values(114,'deepu',12,'07-jan-1994','mno');
insert into Student_Master values(115,'priyanka',10,'01-oct-1994','xyz');
insert into Student_Master values(116,'navi',10,'01-feb-1994','abc');
insert into Student_Master values(117,'priyanka',10,'01-oct-1994','xyz');
insert into Student_Master values(118,'naveen',20,'01-feb-1994','abc');
insert into Student_Master values(115,'priyankan',30,'01-oct-1994','xyz');
insert into Student_Master values(119,'nav',10,'01-feb-1994','abc');


-------------------------------------------

CREATE TABLE Student_Marks
	( Student_Code number(6),
	  Student_Year number not null,
	  Subject1 number(3),
	  Subject2 number(3),
	  Subject3 number(3)
	);

--------------------------------------------

CREATE TABLE Staff_Master
	 ( Staff_code number(8) not null,
	   Staff_Name varchar2(50) not null,
	   Design_code number,
	   Dept_code number,
	   HireDate date,
	   Staff_dob date,
	   Staff_address varchar2(240),
	   Mgr_code number(8),
	   Staff_sal number(10,2)
	  );

alter table staff_master 
add mgr_name varchar(50);	 
	 
insert into Staff_Master values ( 110,'rahul',101,1,'01-oct-2002','10-oct-1994','model colony','1000',15000);
insert into Staff_Master values ( 111,'nitika',101,2,'01-aug-2000','12-april-1993','abc colony','1001',23000);
insert into Staff_Master values ( 112,'aman',102,1,'01-nov-2008','26-may-1992','model colony','1002',55000);
insert into Staff_Master values ( 113,'vivek',101,2,'01-feb-2001','15-dec-2000','xyz colony','1003',21000);
insert into Staff_Master values ( 114,'priya',102,1,'01-dec-2003','09-feb-1994','xyz colony','1004',15000);
insert into Staff_Master values ( 115,'mittali',102,2,'01-march-2010','24-jan-1995','abc colony','1005',35000);
insert into Staff_Master values ( 116,'ri_a',101,2,'01-feb-2001','15-dec-2000','xyz colony',null,21000);
insert into Staff_Master values ( 117,'pra_chi',102,1,'01-dec-2003','09-feb-1994','xyz colony',null,15000);
insert into Staff_Master values ( 118,'raman',102,2,'01-march-2010','24-jan-1995','abc colony','1008',35000);
insert into Staff_Master values ( 119,'ramesh',102,3,'01-march-2010','24-jan-1995','abc colony','1009',35000);
insert into Staff_Master values ( 120,'richa',101,2,'01-feb-2001','15-dec-2000','xyz colony',null,11000);

update staff_master set mgr_name='aaa' where staff_code=110;
update staff_master set mgr_name='bbb' where staff_code=111;
update staff_master set mgr_name='ccc' where staff_code=112;
update staff_master set mgr_name='aaa' where staff_code=113;
update staff_master set mgr_name='aaa' where staff_code=114;
update staff_master set mgr_name='bbb' where staff_code=115;
update staff_master set mgr_name='ccc' where staff_code=116;
update staff_master set mgr_name='ccc' where staff_code=117;
update staff_master set mgr_name='ccc' where staff_code=118;
update staff_master set mgr_name='bbb' where staff_code=119;

------------------------------------------------

CREATE TABLE Book_Master
	( Book_Code number(10) not null,
 	  Book_Name varchar2(50) not null
	  Book_pub_year number,
	  Book_pub_author varchar2(50) not null
	 );

insert into Book_Master values(110,'rd sharma',2002,'abc');
insert into Book_Master values(111,'let us'||'&'||'c',2001,'abc');
insert into Book_Master values(112,'maths',2008,'xyz');
insert into Book_Master values(113,'phy'||'&'||'ics',2004,'xyz');
insert into Book_Master values(114,'chemistry',2007,'aaa');
insert into Book_Master values(115,'eme',2010,'bbb');
--------------------------------------------

CREATE TABLE Book_Transactions
	( Book_Code number,
	  Student_code number,
	  Staff_code number,
	  Book_Issue_date date not null,
	  Book_expected_return_date date not null,
	  Book_actual_return_date date
	);
	
	insert into book_transactions values(110,111,110,'01-oct-2018','19-sep-2018','20-sep-2018');