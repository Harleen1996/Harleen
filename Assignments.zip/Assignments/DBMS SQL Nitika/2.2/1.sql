select round(max(staff_sal)) as "Maximum", round(min(staff_sal)) as "Minimum", round(sum(staff_sal)) as "Total", round(avg(staff_sal)) as "Average" from staff_master group by dept_code;		
