function sayHello()
{
	document.write("<br>This text is displayed by Calling external function : <h1>Hello World</h1>");
}