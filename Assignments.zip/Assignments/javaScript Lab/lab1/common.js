var msg;
msg="<p><code>The actual script is in external script file called common.js</code></p>";

function addNos(headVar,bodyVar)
{

//TODO: display the contents of the variable "msg" 

//TODO: display the addition of two numbers
document.writeln(msg);
var result= headVar+bodyVar;
document.writeln("The sum of the variables <code>headVar</code> and <code>bodyVar</code> is "+result);
}
