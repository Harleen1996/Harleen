package com.cg.assignment;

public class Node {
	int data; 
	Node next; 
	Node(int d)  { data = d;  next = null; } 
}
