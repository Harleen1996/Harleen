package com.cg.assignment;

public class Problem17 {
	public static int solution( int a[]){
		int count=0,i,j;
		for(i=0;i<a.length;i++){
			for(j=i+1;j<a.length;j++){
				if(a[i]==a[j]&&i<j)
					count++;
			}		
		}
		return count;	
	}
	public static void main(String[] args) {
		int array[]={3,5,6,3,3,5,3,6};
		System.out.println(solution(array));
	}
}
