package com.cg.assignment;

public class ClassSolution {
	public static int solution(int x,int y){
		int count1=0,count2=0,i,binary,k;
		String n="" ;
		k=x*y;
		while(k > 0){
			i=k%2;
			n=n+i;
			k=k/2;
		}
		binary=Integer.parseInt(n);
		while(binary>0){
			if(binary%2==1)
				count1++;
			else
				count2++;
			binary=binary>>1;
		}
		return count1;
	}
public static void main(String[] args) {
		int a=7,b=3;
		System.out.println(solution(a,b));
	}
}
