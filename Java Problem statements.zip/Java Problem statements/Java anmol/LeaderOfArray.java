package com.cg.assignment;

public class LeaderOfArray {
	public static void main(String[] args) {
		int leaderArray[]={1,1,1,1,50};
		int count[]=new int[200];
		int x=0;
		for(int i=0;i<leaderArray.length-1;i++){
			count[i]=1;
			for(int j=i+1;j<leaderArray.length;j++){
				if(leaderArray[i]==leaderArray[j])
					count[i]++;
			}
		}
		for(int i=0;i<leaderArray.length;i++){
			if(count[i]>(leaderArray.length)/2){
				System.out.println(leaderArray[i]+"is the leader of the array");
				x=1;
				break;
			}
		}
	}
}
