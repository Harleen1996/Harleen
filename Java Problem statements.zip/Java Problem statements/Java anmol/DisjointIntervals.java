package com.cg.assignment;

public class DisjointIntervals {
	    public void mergesort(int[] A, int[] B, int[] temp, int[] temp2, int start, int end) {
	        if(start < end) {
	            int mid = (start + end)/2;
	            mergesort(A, B, temp, temp2, start, mid);
	            mergesort(A, B, temp, temp2, mid+1, end);
	            merge(A, B, temp, temp2, start, mid+1, end);
	        }
	    }

	    public void merge(int[] A, int B[], int[] temp, int[] temp2, int start, int mid, int end) {
	        int leftEnd = mid - 1;
	        int left = start;
	        int size = end - start + 1;
	        int k = start;

	        while(left <= leftEnd && mid <= end) {
	            if(A[left] <= A[mid]) {
	                temp[k] = A[left];
	                temp2[k] = B[left];
	                k++; left++;
	            }
	            else {
	                temp[k] = A[mid];
	                temp2[k] = B[mid];
	                k++; mid++;
	            }
	        }
	        while(left <= leftEnd) {
	            temp[k] = A[left];
	            temp2[k] = B[left];
	            left++; k++;
	        }
	        while(mid <= end) {
	            temp[k] = A[mid];
	            temp2[k] = B[mid];
	            mid++; k++;
	        }
	        for(int i = 0; i < size; i++) {
	            A[end] = temp[end];
	            B[end] = temp2[end];
	            end--;
	        }
	    }

	    public int evaluateList(int[] A, int[] B) {
	        int count = 1;
	        int maxB  = B[0];

	        for (int i = 1; i < A.length; i++) {
	            if (A[i] <= maxB) {
	                maxB = maxB > B[i] ? maxB : B[i];
	            } else {
	                count++;
	                maxB = B[i];
	            }
	        }
	        return count;
	    }

	    public int solution(int[] A, int[] B) {
	        int[] temp = new int[A.length];
	        int[] temp2 = new int[A.length];
	        mergesort(A, B, temp, temp2, 0, A.length-1);
	        return evaluateList(A, B);
	    }

	public static void main(String[] args) {
	int a[]={1,12,42,70,36,-4,43,15};
	int b[]={5,15,44,72,36,2,69,24};
	DisjointIntervals dInt=new DisjointIntervals();
    int x=dInt.solution(a,b);
    System.out.println(x);
	}
}
