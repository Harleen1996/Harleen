package com.cg.assignment;

public class LinkedList {
	public static void main(String[] args) {
		int array[]={1,2,6,4,3};
		int count=0;
		for(int i=array.length-1;i>0;i--){
			if(array[i]<array[i-1]){
				int j=i-1;
				while(j>=0 && (array[i]<array[j])){
					j--;
				}
				int temp=array[j+1];
				array[j+1]=array[i];
				array[i]=temp;
				count++;
			}
		}
		if(count>1)
			System.out.println("false");
		else
			System.out.println("true");
	}
}
