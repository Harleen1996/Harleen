package com.cg.assignment;

public class Problem15 {
	static int solution(String S) { 
        int n=S.length();
        int Nopen[] = new int[n+1]; 
        int close[] = new int[n+1]; 
        int k = 0; 
       
        Nopen[0] = 0; 
        close[n] = 0; 
        if (S.charAt(0)=='(') 
            Nopen[1] = 1; 
        if (S.charAt(n-1) == ')') 
            close[n-1] = 1; 
        for (int i = 1; i < n; i++) { 
            if ( S.charAt(i) == '(' ) 
                Nopen[i+1] = Nopen[i] + 1; 
            else
                Nopen[i+1] = Nopen[i]; 
        } 
        for (int i = n-2; i >= 0; i--) { 
            if ( S.charAt(i) == ')' ) 
                close[i] = close[i+1] + 1; 
            else
                close[i] = close[i+1]; 
        } 
        if (Nopen[n] == 0) 
            return n; 
        if (close[0] == 0) 
            return 0; 
        
        for (int i=0; i<=n; i++) 
            if (Nopen[i] == close[i]) 
                k = i; 
       
        return k; 
    } 
      

    public static void main(String[] args) { 
        String string = "(())))("; 
        System.out.println(solution(string)); 
    } 
}
