
public class NumberOfBits {
	static int count=0;
	static String bin="";
	public int solution(int a,int b){ 
		int temp,mul=a*b;
		while(mul>0){
			temp=mul%2;
			bin = temp+""+bin ;
			if(temp==1)
				count++;
			mul=mul/2;
		}
		return count;
	}
	public static void main(String[] args) {
		int a=3,b=7;
		NumberOfBits obj=new NumberOfBits();
		obj.solution(a,b);
		System.out.println(bin);
		System.out.println(count);
	}
}
