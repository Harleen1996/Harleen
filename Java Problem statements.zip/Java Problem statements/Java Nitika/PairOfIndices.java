
public class PairOfIndices {
	public int solution(int[] A, int[] B) {
		float[] C = new float[A.length];
		float[] A1 = new float[A.length];
		float[] B1 = new float[B.length];
		int i,j,count=0;
		for ( i = 0 ; i < A.length; i++){
		    A1[i] = (float) A[i];
		    B1[i]=(float)B[i];
		}
		for(i=0;i<C.length;i++){
			C[i]=(A1[i]+(B1[i]/1000000));
			System.out.println(C[i]);
		}
		for(i=0;i<C.length;i++)
			for(j=i+1;j<C.length;j++)
				if(C[i]*C[j]>= C[i]+C[j])
					count++;
		System.out.println(count);
		return 0;
	}
	public static void main(String[] args) {
		int []numList1={0,1,2,2,3,5};
		int []numList2={500000,500000,0,0,0,20000};
		PairOfIndices obj=new PairOfIndices();
		obj.solution(numList1, numList2);


	}

}
