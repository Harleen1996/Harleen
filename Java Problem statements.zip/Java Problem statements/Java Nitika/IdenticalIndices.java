
public class IdenticalIndices {
	static int count = 0; 
	public int solution(int[] A){
	    for (int i=0;i<A.length;i++) 
	        for (int j= i+1;j<A.length;j++) 
	            if (A[i]==A[j]) 
	                count++; 
		return count;	
	}
	public static void main(String[] args) {
		IdenticalIndices obj=new IdenticalIndices();
		int []numList={3,5,6,3,3,5};
		obj.solution(numList);
		System.out.println(count);
	}
}
