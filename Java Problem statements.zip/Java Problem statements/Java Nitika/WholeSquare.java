
public class WholeSquare {
	static int count=0;
	int solution(int A, int B){
		int i,j;
		for(i=A;i<=B;i++)
			for(j=1;j*j<=i;j++) 
	            if (j*j == i) 
	                count++; 
		return count;	
	}
	public static void main(String[] args) {
		WholeSquare obj=new WholeSquare();
		int result=obj.solution(4,17);
		System.out.println(count);

	}

}
