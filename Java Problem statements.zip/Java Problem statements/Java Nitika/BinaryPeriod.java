
public class BinaryPeriod {
	public int solution(int N){
		int []numList = new int[50];
		int Q=0,P;
		while(N>0){
	        numList[Q]=N%2 ;
	        N =N/2;
	        Q++;
	    }
		for(P=Q/2;P>0;P--){
			int flag=1;
			for(int i=0;i<(Q-Q/2);i++){
				if(numList[i]!=numList[i+P]){
					flag=0;
					break;
				}
			}
	        if(flag==1)
	            return P;
		}
		return -1;
	}
	public static void main(String[] args) {
		BinaryPeriod obj=new BinaryPeriod();
		int result=obj.solution(955);
		System.out.println(result);
	}

}
