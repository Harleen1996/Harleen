class Array{
	public static void main(String[] str){
		int n=8,flag=0;
		int numList[]={2,17,13,14,15,6,7,8,29,10};
		for(int i=0;i<10;i++)
			if(n==numList[i]){
				flag=1;
				System.out.println("Number found on index "+numList[i]);		
				break;
			}
		if(flag==0)
			System.out.println("Number not found ");
	}
}